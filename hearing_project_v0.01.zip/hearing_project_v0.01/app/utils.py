# app/utils.py
from pathlib import Path
import re
from typing import Tuple, Optional, Any
from bson import ObjectId
import datetime
import os
from unidecode import unidecode

def ascii_translit(s: str) -> str:
    return re.sub(r"[^\w\-_.]", "", unidecode(s or "")) or "word"

def safe_unicode_filename(s: str) -> str:
    s = (s or "").strip()
    s = re.sub(r"[\\/:\*\?\"<>\|]", "_", s)
    s = re.sub(r"\s+", "_", s)
    return s[:60]

def expected_filenames(section: str, idx: str, sinhala_word: str):
    idx = str(idx).zfill(2)
    uni = safe_unicode_filename(sinhala_word or "")
    ascii_name = ascii_translit(sinhala_word or "")
    return [f"{idx}_{uni}_{ascii_name}.mp3", f"{idx}_{uni}.mp3"]

def project_root() -> Path:
    return Path(__file__).resolve().parents[1]

def filesystem_root_for_audio(audio_root_setting: str) -> Path:
    ar = Path(audio_root_setting)
    if ar.is_absolute():
        return ar
    return (project_root() / ar)

def find_audio_file(audio_root_setting: str, section: str, index: str, sinhala_word: str) -> Tuple[Optional[str], Optional[str]]:
    fs_root = filesystem_root_for_audio(audio_root_setting)
    section_dir = fs_root / section
    if not section_dir.exists():
        return None, None

    for fname in expected_filenames(section, index, sinhala_word):
        fs_path = section_dir / fname
        if fs_path.exists():
            rel_db_path = str(Path(audio_root_setting) / section / fname).replace("\\", "/")
            url = f"/audio/{section}/{fname}"
            return rel_db_path, url

    files = list(section_dir.glob("*.mp3"))
    if files:
        chosen = files[0]
        rel_db_path = str(Path(audio_root_setting) / section / chosen.name).replace("\\", "/")
        url = f"/audio/{section}/{chosen.name}"
        return rel_db_path, url

    return None, None

def mongo_to_jsonable(obj: Any) -> Any:
    if obj is None:
        return None
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if isinstance(v, ObjectId):
                out[k] = str(v)
            elif isinstance(v, (datetime.datetime, datetime.date)):
                out[k] = v.isoformat()
            elif isinstance(v, list):
                out[k] = [mongo_to_jsonable(x) for x in v]
            elif isinstance(v, dict):
                out[k] = mongo_to_jsonable(v)
            else:
                out[k] = v
        return out
    if isinstance(obj, list):
        return [mongo_to_jsonable(x) for x in obj]
    if isinstance(obj, ObjectId):
        return str(obj)
    if isinstance(obj, (datetime.datetime, datetime.date)):
        return obj.isoformat()
    return obj
