# app/main.py
import os
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from . import db as db_module

# Resolve AUDIO_ROOT like loader: relative paths are interpreted relative to project root
def _project_root():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def _filesystem_audio_root(audio_root_setting: str):
    if os.path.isabs(audio_root_setting):
        return audio_root_setting
    return os.path.join(_project_root(), audio_root_setting)

AUDIO_ROOT = os.getenv("AUDIO_ROOT", "swara_audio_cloud")
FILESYSTEM_AUDIO_ROOT = _filesystem_audio_root(AUDIO_ROOT)

app = FastAPI(title="Hearing Project API")

# Import routers after app created
from .routes import session  # ensures routes import works

app.include_router(session.router)

@app.on_event("startup")
async def startup():
    # initialize motor client and set module-level db variable
    db_module.init_client()
    # Print info (visible in uvicorn logs)
    print(f"Startup: MongoDB client initialized, audio mounted at: {FILESYSTEM_AUDIO_ROOT}")

    # mount the filesystem audio folder (if it exists)
    if os.path.isdir(FILESYSTEM_AUDIO_ROOT):
        app.mount("/audio", StaticFiles(directory=FILESYSTEM_AUDIO_ROOT), name="audio")
        print(f"Mounted /audio -> {FILESYSTEM_AUDIO_ROOT}")
    else:
        # still mount a missing directory to avoid 404 behavior changes (but warn)
        try:
            os.makedirs(FILESYSTEM_AUDIO_ROOT, exist_ok=True)
            app.mount("/audio", StaticFiles(directory=FILESYSTEM_AUDIO_ROOT), name="audio")
            print(f"Created and mounted /audio -> {FILESYSTEM_AUDIO_ROOT}")
        except Exception as e:
            print("Warning: could not mount audio directory:", e)

@app.on_event("shutdown")
async def shutdown():
    db_module.close_client()
