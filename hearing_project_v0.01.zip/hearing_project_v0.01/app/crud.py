# app/crud.py
"""
Database CRUD helpers for the Hearing Project.

Key behaviors:
 - Uses string UUIDs for sessions/docs where possible, but supports collections that may use ObjectId.
 - Normalizes doc id references in session events to strings so session.events are consistent.
 - When updating docs by id, attempts string-keyed update first, then an ObjectId fallback.
 - Provides simple helpers used by routes (pick_random_for_vowel, mark_presented, etc).
"""
import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from . import db as db_module  # import the module, not the variable
from motor.motor_asyncio import AsyncIOMotorDatabase

# try import ObjectId for fallback conversions
try:
    from bson import ObjectId  # type: ignore
except Exception:  # pragma: no cover - bson should be present in normal env
    ObjectId = None  # type: ignore

def now_ts() -> str:
    return datetime.utcnow().isoformat()

async def insert_rows(rows: List[Dict[str,Any]]) -> int:
    """Insert multiple doc rows into db.docs. Returns inserted count."""
    if not rows:
        return 0
    docs = []
    for r in rows:
        docs.append({
            "_id": str(uuid.uuid4()),
            "section": r.get("section","unknown"),
            "index": str(r.get("index","")).zfill(2),
            "sinhala_word": r.get("sinhala_word",""),
            "singlish": r.get("singlish",""),
            "main_vowel_name": r.get("main_vowel_name",""),
            "main_vowel_char": r.get("main_vowel_char",""),
            "audio_path": r.get("audio_path"),
            "audio_url": r.get("audio_url"),
            "presented": False,
            "user_events": []
        })
    res = await db_module.db.docs.insert_many(docs)
    return len(res.inserted_ids)

async def upsert_doc_by_keys(section: str, index: str, sinhala_word: str, payload: Dict[str,Any]) -> None:
    """Update or insert a single doc identified by section+index+sinhala_word."""
    query = {"section": section, "index": index, "sinhala_word": sinhala_word}
    await db_module.db.docs.update_one(query, {"$set": payload}, upsert=True)

async def get_all_docs() -> List[Dict[str,Any]]:
    cursor = db_module.db.docs.find({})
    return [d async for d in cursor]

async def get_doc_by_id(doc_id: str) -> Optional[Dict[str,Any]]:
    """
    Try to fetch a document by its _id. Try string id first, then ObjectId fallback.
    Returns None if not found.
    """
    if not doc_id:
        return None
    # try as string first
    doc = await db_module.db.docs.find_one({"_id": doc_id})
    if doc:
        return doc
    # fallback to ObjectId if available and looks like one
    if ObjectId is not None:
        try:
            oid = ObjectId(doc_id)
            doc = await db_module.db.docs.find_one({"_id": oid})
            return doc
        except Exception:
            return None
    return None

async def pick_random_for_vowel(vowel: str, exclude_presented: bool=False) -> Optional[Dict[str,Any]]:
    """Return a random doc for the vowel; if exclude_presented True prefer docs where presented=False."""
    q: Dict[str,Any] = {"main_vowel_name": vowel}
    if exclude_presented:
        q["presented"] = False
    cursor = db_module.db.docs.find(q)
    docs = [d async for d in cursor]
    if not docs:
        return None
    import random
    return random.choice(docs)

async def find_same_index_pair(doc: Dict[str,Any]) -> Optional[Dict[str,Any]]:
    """Find another doc with same section+index but different _id."""
    if not doc or not doc.get("section") or not doc.get("index"):
        return None
    return await db_module.db.docs.find_one({
        "section": doc["section"],
        "index": doc["index"],
        "_id": {"$ne": doc["_id"]}
    })

async def mark_presented(doc_id: str) -> None:
    """
    Mark doc presented=True. Accepts string-id; if update didn't match try ObjectId fallback.
    Does not raise if nothing matched.
    """
    if not doc_id:
        return
    # try string update first
    try:
        res = await db_module.db.docs.update_one({"_id": doc_id}, {"$set": {"presented": True}})
        if getattr(res, "matched_count", 0):
            return
    except Exception:
        # continue to fallback
        pass

    # try ObjectId fallback
    if ObjectId is not None:
        try:
            oid = ObjectId(doc_id)
            await db_module.db.docs.update_one({"_id": oid}, {"$set": {"presented": True}})
        except Exception:
            pass

async def create_session(vowel_sequence: List[str], max_vowels: int) -> Dict[str,Any]:
    """Create a new session document and return it (session._id is a UUID string)."""
    session = {
        "_id": str(uuid.uuid4()),
        "started_at": now_ts(),
        "vowel_sequence": vowel_sequence[:max_vowels],
        "test_index": 0,
        "primary_doc": None,
        "primary_role": None,
        "original_primary_doc_id": None,
        "visible_options": {},
        "events": [],
        "results": {}
    }
    await db_module.db.sessions.insert_one(session)
    return session

async def get_session(session_id: str) -> Optional[Dict[str,Any]]:
    if not session_id:
        return None
    return await db_module.db.sessions.find_one({"_id": session_id})

async def update_session(session_id: str, patch: Dict[str,Any]) -> Optional[Dict[str,Any]]:
    """Apply patch (dict) to session and return the updated session."""
    await db_module.db.sessions.update_one({"_id": session_id}, {"$set": patch})
    return await get_session(session_id)

async def push_event(session_id: str, ev: Dict[str,Any]) -> None:
    """
    Push an event into sessions.events and also attach to docs.user_events if the event references a doc.
    This function normalizes doc ids to strings in the payload and attempts to update docs regardless
    of whether their _id is stored as ObjectId or string.
    """
    ev = ev or {}
    ev["ts"] = now_ts()

    # normalize payload doc id fields to strings if present
    payload = ev.get("payload", {}) or {}
    # common keys that may reference docs in your events
    doc_keys = ("doc_id", "presented_doc_id", "target_doc_id", "confirm_doc_id", "chosen_doc_id")
    for k in doc_keys:
        if k in payload and payload[k] is not None:
            try:
                payload[k] = str(payload[k])
            except Exception:
                # keep original if cannot convert
                pass
    ev["payload"] = payload

    # push event into session.events
    await db_module.db.sessions.update_one({"_id": session_id}, {"$push": {"events": ev}})

    # if event references a doc id, attach the event to that doc's user_events array
    doc_id = payload.get("doc_id") or payload.get("presented_doc_id") or payload.get("target_doc_id") or payload.get("confirm_doc_id") or payload.get("chosen_doc_id")
    if not doc_id:
        return

    # try update by string id
    try:
        res = await db_module.db.docs.update_one({"_id": doc_id}, {"$push": {"user_events": ev}})
        if getattr(res, "matched_count", 0):
            return
    except Exception:
        pass

    # try update by ObjectId (if possible)
    if ObjectId is not None:
        try:
            oid = ObjectId(doc_id)
            await db_module.db.docs.update_one({"_id": oid}, {"$push": {"user_events": ev}})
        except Exception:
            # if still fails, nothing else to do (event still stored in session)
            return
